loadstring(game:HttpGet("https://raw.githubusercontent.com/debug420/Ez-Hub/master/OBFUSCATED_7cc4c03_EzHub.txt", true))()
